
export default function Plans () {
    return (
        <section>
            
        </section>
    )
}