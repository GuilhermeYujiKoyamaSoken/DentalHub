import { auth } from './auth'

export default auth;